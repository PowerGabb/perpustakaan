
<?php $__env->startSection('content'); ?>
    <div>
        <?php if(session()->has('error')): ?>
            <p class="text-danger pt-2"><?php echo e(session('error')); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">Detail User</div>
            <div class="card-body">
                <form action="/profile" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name" class="form-label">Nama Lengkap:</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($profile->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="name" class="form-label">NISN:</label>
                        <input type="text" name="nisn" class="form-control" value="<?php echo e($profile->nisn); ?>">
                    </div>
                    <div class="form-group">
                        <label for="name" class="form-label">Kelas:</label>
                        <select name="class" id=""  value="<?php echo e($profile->class); ?>" id="class" class="kelas form-control" single>
                            <option value="10 RPL 1">10 RPL 1</option>
                            <option value="10 RPL 2">10 RPL 2</option>
                            <option value="11 RPL 1">11 RPL 1</option>
                            <option value="11 RPL 2">11 RPL 2</option>
                            <option value="12 RPL 1">12 RPL 1</option>
                            <option value="12 RPL 2">12 RPL 2</option>
                            <option value="10 TKJ 1">10 TKJ 1</option>
                            <option value="11 TKJ 1">11 TKJ 1</option>
                            <option value="12 TKJ 1">12 TKJ 1</option>
                            <option value="10 OTKP 1">10 OTKP 1</option>
                            <option value="11 OTKP 1">11 OTKP 1</option>
                            <option value="12 OTKP 1">12 OTKP 1</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="name" class="form-label">Email:</label>
                        <input type="text" name="email" class="form-control" value="<?php echo e($profile->email); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/account/edit.blade.php ENDPATH**/ ?>