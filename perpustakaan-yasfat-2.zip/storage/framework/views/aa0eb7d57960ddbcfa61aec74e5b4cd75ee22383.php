
<?php $__env->startSection('title', 'Account'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-xxl flex-grow-1 container-p-y">


        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="">Informasi Akun</h5>
                    </div>
                    
                    
                    <!-- Account -->
                    <div class="card-body">
                        <div class="d-flex align-items-start align-items-sm-center gap-4">
                            <?php if(auth()->user()->avatar): ?>
                            <img src="<?php echo e(asset('storage/photo/'.auth()->user()->avatar)); ?>" alt="user-avatar" class="d-block rounded" height="100"
                            width="100" id="uploadedAvatar" />
                            <?php else: ?>
                            <img src="<?php echo e(asset('sneat/img/avatars/1.png')); ?>" alt="">
                            <?php endif; ?>

                            
                            
                        </div>
                        
                    </div>
                    <hr class="my-0" />
                    <div class="card-body">
                        <form id="formAccountSettings" method="POST" onsubmit="return false">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="firstName" class="form-label">Nama Lengkap</label>
                                    <input class="form-control" type="text" id="firstName" name="firstName"
                                        value="<?php echo e($profile->name); ?>" autofocus disabled />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="lastName" class="form-label">NISN</label>
                                    <input class="form-control" type="text" name="lastName" id="lastName"
                                        value="<?php echo e($profile->nisn); ?>" disabled />
                                </div>
                                <div class="mb-3 col-lg-12">
                                    <label for="currency" class="form-label">Kelas</label>
                                    <input type="text" class="form-control" value="<?php echo e($profile->class); ?>" disabled>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input class="form-control" type="text" id="email" name="email"
                                        value="<?php echo e($profile->email); ?>" placeholder="john.doe@example.com" disabled />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="organization" class="form-label">Status</label>
                                    <input type="text" class="form-control" id="organization" name="role"
                                        value="<?php echo e($profile->role); ?>" disabled />
                                </div>
                                <div class="mb-3 col-md-12">
                                    <label class="form-label" for="phoneNumber">Nomor Telepon</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text">ID (+62)</span>
                                        <input type="text" id="phoneNumber" name="phoneNumber" class="form-control"
                                            placeholder="<?php echo e($profile->phone); ?>" disabled />
                                    </div>
                                </div>
                                <div class="mb-3 col-md-12">
                                    <label for="address" class="form-label">Alamat</label>
                                    <textarea name="address" class="form-control" id="" value="<?php echo e($profile->address); ?>" cols="30"
                                        rows="10" disabled><?php echo e($profile->address); ?></textarea>
                                </div>

                               
                            </div>
                            <div class="mt-2">
                                <a href="/profile/edit" class="btn btn-primary me-2">Edit Profile</a>
                                <?php if(auth()->user()->role == 'admin'): ?>
                                <?php else: ?>
                                <a href="/print-card" class="btn btn-outline-warning">Cetak Kartu Anggota</a>
                                <?php endif; ?>
                                
                            </div>
                        </form>
                    </div>
                    <!-- /Account -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/account/index.blade.php ENDPATH**/ ?>