
<?php $__env->startSection('title', 'Perpustakaan | Pinjamanku'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h3>Pinjamanku</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="myTable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Buku <i class="bx bx-filter"></i></th>
                                        <th>Status <i class="bx bx-filter"></i></th>
                                        <th>Tgl Pinjam <i class="bx bx-filter"></i></th>
                                        <th>Tgl Kembali <i class="bx bx-filter"></i></th>
                                        <th>Denda Terlambat <i class="bx bx-filter"></i></th>
                                        <th>Tgl Wajib Kembali <i class="bx bx-filter"></i></th>
                                        <th>Bayar Denda</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->book->title); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td><?php echo e($item->rent_at); ?></td>
                                            <td><?php echo e($item->return_at); ?></td>
                                            <td class="text-danger font-weight-bold text-center"><?php echo e($item->denda); ?></td>
                                            <td><?php echo e($item->rent_time_limit); ?></td>
                                            <td>
                                                <?php if($item->denda > 0 && $item->status != 'denda dibayar'): ?>
                                                    <a href="/pay-fine/<?php echo e($item->id); ?>" class="btn btn-primary">Bayar Denda</a>
                                                <?php else: ?>
                                                    <span>-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="">
                                                <p class="text-center text-danger">No Data</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php if($errors->any()): ?>
<div class="bs-toast toast fade show bg-success position-fixed bottom-0 end-0 m-3" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <i class="bx bx-bell me-2"></i>
      <div class="me-auto fw-semibold">Berhasil</div>
      <small>Now</small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">
      <?php echo e($errors->first()); ?>

    </div>
</div>

<style>
    @media (max-width: 767px) {
        .bs-toast {
            max-width: 200px;
            font-size: 12px;
        }
    }
</style>
<?php endif; ?>

<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/account/pinjamanku.blade.php ENDPATH**/ ?>