
<?php $__env->startSection('title', 'Perpustakaan | Yasfat'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container contents">

        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'menunggu aktivasi'): ?>
                <div class="row">
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>Selamat Anda Berhasil Register, Namun Akun Anda Belum Terverifikasi Oleh Admin Dan Belum Bisa Meminjam</strong>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="header-box d-flex align-items-center row">
            <div class="col-lg-6">
                <h1 class="mb-4"><span style="color: red;">Perpustakaan Yasfat</span><br>Bersama Kami</h1>
                <p class="mb-3">Selamat datang di Perpustakaan Yasfat, tempat di mana pengetahuan dan inspirasi bertemu
                    dalam harmoni sempurna. Kami tidak hanya sekadar sebuah perpustakaan; kami adalah pusat kearifan yang
                    mengundang Anda untuk menjelajahi dunia pengetahuan dengan penuh semangat dan keingintahuan.</button>
                <div>
                    <a href="/book" class="btn btn-primary">Cari Buku</a>
                </div>
            </div>
            <div class="pt-lg-0 pt-5 d-flex justify-content-center align-items-center col-lg-6">
                <img src="<?php echo e(asset('storage/logo/'. $logo->logo)); ?>" alt="">
            </div>
        </div>
    </div>

    <div class="container hotbook">

        <h1 class="align-center mb-5 text-center">Buku Terbaru</h1>

        <div class="row row-cols-1 row-cols-md-4 g-3 mt-4">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col mb-3">
                    <div class="card shadow h-100">
                        <?php if($item->cover): ?>
                            <img src="<?php echo e(asset('storage/cover/' . $item->cover)); ?>" alt="unsplash.com"
                                class="card-img-top rounded mt-3 px-3">
                        <?php else: ?>
                            <img src="<?php echo e(asset('default.png')); ?>" alt="unsplash.com" class="card-img-top rounded mt-3 px-3">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->title); ?></h5>
                            <p class="card-text"><?php echo e($item->description); ?></p>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <a href="/book/<?php echo e($item->id); ?>" class="btn btn-primary btn-sm">Selengkapnya</a>
                            <small class="text-muted"><?php echo e($item->created_at->diffForHumans()); ?></small>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    </div>

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/public/index.blade.php ENDPATH**/ ?>