
<?php $__env->startSection('content'); ?>
    <div>
        <div class="card">
            <div class="card-header"><?php echo e($profile->name); ?></div>
            <div class="card-body">
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($profile->name); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">NISN:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($profile->nisn); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">Kelas:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($profile->class); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">Email:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($profile->email); ?>" readonly>
                </div>

                <a href="profile/edit" class="btn btn-primary">Edit profiles</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/account/index.blade.php ENDPATH**/ ?>