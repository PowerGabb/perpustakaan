
<?php $__env->startSection('title', 'Detail'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container contents">
        <div class="row">
            <div class="col-md-12 col-lg-12 mb-5">
                <div class="card h-100 w-100">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-12 col-lg-4">
                                <?php if($book->cover != ''): ?>
                                    <img class="img-fluid d-flex mx-auto my-4"
                                        src="<?php echo e(asset('storage/cover/' . $book->cover)); ?>" alt="Card image cap">
                                <?php else: ?>
                                    <img class="img-fluid d-flex mx-auto my-4" src="<?php echo e(asset('default.png')); ?>"
                                        alt="Card image cap">
                                <?php endif; ?>
                            </div>
                            <div class="col-12 col-lg-8 pt-4">
                                <h5 class="card-title"><?php echo e($book->title); ?></h5>
                                <h6 class="card-subtitle text-muted mb-4">Kategori:
                                    <?php $__currentLoopData = $book->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($datass->title); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </h6>
                                <h6 class="card-subtitle text-muted mb-4">Kode Buku:
                                    <p><?php echo e($book->book_code); ?></p>
                                </h6>
                                <h6 class="card-subtitle text-muted mb-4">Jumlah Stok:
                                    <p><?php echo e($book->jumlah); ?></p>
                                </h6>
                                <p class="card-text mb-5">
                                    <?php echo $book->description; ?>

                                </p>
                                <a href="/pinjam/buku/<?php echo e($book->id); ?>" class="btn btn-outline-primary w-100">Pinjam</a>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php if(Session::has('success')): ?>
        <div class="bs-toast toast fade show bg-success bottom-0 end-0 position-fixed m-3" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="bx bx-bell me-2"></i>
                <div class="me-auto fw-semibold">Berhasil</div>
                <small>sec ago</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e(Session::get('success')); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/public/book-detail.blade.php ENDPATH**/ ?>