<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Account</title>
</head>
<body>
    
    <div>
        <h1>Nama: <?php echo e($account->name); ?></h1>
        <p>NISN: <?php echo e($account->nisn); ?></p>
        <p>Kelas: <?php echo e($account->class); ?></p>
        <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($account->id, 'C39')); ?>" alt="image">
    </div>
</body>
</html><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/card/card.blade.php ENDPATH**/ ?>