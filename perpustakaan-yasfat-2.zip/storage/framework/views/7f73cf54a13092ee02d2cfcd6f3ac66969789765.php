
<?php $__env->startSection('content'); ?>

    <div class="col-xxl">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">Tambah Peminjaman</h5>
                <small class="text-muted float-end"></small>
            </div>
            <div class="card-body">
                <form action="/rents" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="user">User</label>
                        <div class="col-sm-10">
                            <select name="user_id" id="user" class="form-select inputbox">
                                <option value="">Select User</option>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items->id); ?>"><?php echo e($items->id); ?>.<?php echo e(Str::ucfirst($items->name)); ?> - <?php echo e($items->class); ?> -</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="book">Book</label>
                        <div class="col-sm-10">
                            <select name="book_id" id="book" class="form-select inputbox">
                                <option value="">Select Book</option>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e(Str::ucfirst($item->title)); ?> - <?php echo e($item->book_code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="bs-toast toast fade show bg-danger position-fixed bottom-0 end-0 m-3" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="bx bx-bell me-2"></i>
                <div class="me-auto fw-semibold">Berhasil</div>
                <small>Now</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e($errors->first()); ?>

            </div>
        </div>

        <style>
            @media (max-width: 767px) {
                .bs-toast {
                    max-width: 200px;
                    font-size: 12px;
                }
            }
        </style>
    <?php endif; ?>
    
    <?php if(Session::get('status') == 'failed'): ?>
        <div class="bs-toast toast fade show <?php if(Session::get('message') == 'Buku berhasil di pinjam'): ?>
        bg-success
        <?php else: ?>
        bg-danger
        <?php endif; ?> position-fixed bottom-0 end-0 m-3" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="bx bx-bell me-2"></i>
                <div class="me-auto fw-semibold">Berhasil</div>
                <small>Now</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e(Session::get('message')); ?>

            </div>
        </div>

        <style>
            @media (max-width: 767px) {
                .bs-toast {
                    max-width: 200px;
                    font-size: 12px;
                }
            }
        </style>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/rents/create.blade.php ENDPATH**/ ?>