
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3>Riwayat Peminjaman</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Peminjam</th>
                                    <th>Buku <i class="bx bx-filter"></i></th>
                                    <th>Status <i class="bx bx-filter"></i></th>
                                    <th>Tgl Pinjam <i class="bx bx-filter"></i></th>
                                    <th>Tgl Kembali <i class="bx bx-filter"></i></th>
                                    <th>Denda Terlambat <i class="bx bx-filter"></i></th>
                                    <th>Tgl Wajib Kembali <i class="bx bx-filter"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->user->name); ?></td>
                                        <td><?php echo e($item->book->title); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td><?php echo e($item->rent_at); ?></td>
                                        <td><?php echo e($item->return_at); ?></td>
                                        <td class="text-danger font-weight-bold text-center"><?php echo e($item->denda); ?></td>
                                        <td><?php echo e($item->rent_time_limit); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8">
                                            <p class="text-center text-danger">No Data</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/rents/index.blade.php ENDPATH**/ ?>